/**
 */
package org.rm2pt.sample.basicfamily.metamodel.basicfamily;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>People</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.rm2pt.sample.basicfamily.metamodel.basicfamily.BasicfamilyPackage#getPeople()
 * @model
 * @generated
 */
public interface People extends EObject {
} // People
