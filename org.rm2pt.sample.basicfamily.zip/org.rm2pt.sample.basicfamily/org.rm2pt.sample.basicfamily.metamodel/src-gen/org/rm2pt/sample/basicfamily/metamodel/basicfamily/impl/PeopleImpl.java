/**
 */
package org.rm2pt.sample.basicfamily.metamodel.basicfamily.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.rm2pt.sample.basicfamily.metamodel.basicfamily.BasicfamilyPackage;
import org.rm2pt.sample.basicfamily.metamodel.basicfamily.People;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>People</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PeopleImpl extends MinimalEObjectImpl.Container implements People {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PeopleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BasicfamilyPackage.Literals.PEOPLE;
	}

} //PeopleImpl
