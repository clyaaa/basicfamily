/**
 */
package org.rm2pt.sample.basicfamily.metamodel.basicfamily.impl;

import org.eclipse.emf.ecore.EClass;

import org.rm2pt.sample.basicfamily.metamodel.basicfamily.BasicfamilyPackage;
import org.rm2pt.sample.basicfamily.metamodel.basicfamily.Women;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Women</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class WomenImpl extends PersonImpl implements Women {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WomenImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BasicfamilyPackage.Literals.WOMEN;
	}

} //WomenImpl
