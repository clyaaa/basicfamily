/**
 */
package org.rm2pt.sample.basicfamily.metamodel.basicfamily;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Women</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.rm2pt.sample.basicfamily.metamodel.basicfamily.BasicfamilyPackage#getWomen()
 * @model
 * @generated
 */
public interface Women extends Person {
} // Women
